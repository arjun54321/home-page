<?php
include('connection.php');

?>
<!doctype html>
<html>
<head>
	<title>HOME</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
	<style>
	body{
		             margin: 0;
		            font-family: Arial, Helvetica, sans-serif;
		        }
		   .body{	
			 	     background-size : 100% auto;
			 	     background-color:#ADD8E6;
			 	     background-image: url("images/araiel1.jpg");
					 background-repeat: no-repeat;
					 background-position: center center;
					 background-attachment: fixed;
					 background-size: cover;
			    }
		   .topnav{
		             overflow: hidden;
		             background-color: #333;
		             height:70px;
		          }
		   .topnav div {
			                 color: #f2f2f2;
			                 text-align: center;
			                 
			                 padding: 14px 16px;
			                 text-decoration: none;
			                 font-size: 30px;
		               }
		   #myTopnav{
		               
		               line-height: 80px;
		               }
		   .item{
		   	float:right;
		   	padding-left: 30px;
		   	padding-right: 40px;
		   /*font-size: 20px;*/}
		   .item1{
		   	float:right;
		   	background-color: #dd5347;
		   	padding-left: 40px;
		   	padding-right: 50px;
		   /*font-size: 20px;*/}
		   .item2{
		   	float:left;
		   	background-color: #dd5347;
		   	padding-left: 50px;
		   	padding-right: 50px;
		   	padding-bottom: 20px;
		   	padding-top: 20px;
		   /*font-size: 20px;*/}
		   
		   	.myhead {
    			color: #f2f2f2;
    			padding: 0 9%;
    			position: absolute;
    			top: 18%;
    			transition: color 1s;
    			width: 50%;
    			

			}

			
			h1 {
			font-family: "Lucida Console", Monaco, monospace;
    		font-size: 50px;
			}
		   
	</style>
	</head>
	<body class="body" id="body" background="">
	  <div class="topnav" id="myTopnav">
		<a  href="index.php" class="glyphicon glyphicon-home"  style="padding-left: 30px; color:white;font-size:30px"></a>
               <a   href="signup.php" style="color:white" class="gallery"><p class="item1" style="font-size:17px; ">CREATE ACCOUNT </p></a>
				
               <a   href="signin.php" style="color:white"><p class="item" style="font-size:17px;">SIGN IN</p></a>
                
        
	  </div>

	  <div class="myhead">
	  	<h1>Hello!! this is Arjun Singh, how are you?</h1>
	  	<br><br>
	  	<a   href="signup.php" style="color:white" class="gallery"><p class="item2" style="font-size:17px; ">CREATE ACCOUNT </p></a>
		     
	  </div>

	  

	  
	</body>
</html>