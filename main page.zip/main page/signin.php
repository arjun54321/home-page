<?php
include("connection.php");
?>
<html>
<head><title>hello</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
	
	   <style>
	body{
		             margin: 0;
		            font-family: Arial, Helvetica, sans-serif;
		        }
		   .body{	
			 	     background-size : 100% auto;
			 	     background-color:white;
/*			 	     background-image: url("images/araiel1.jpg");
*/					 background-repeat: no-repeat;
					 background-position: center center;
					 background-attachment: fixed;
					 background-size: cover;
			    }
		   .topnav{
		             overflow: hidden;
		             background-color: #333;
		             height:70px;
		          }
		   .topnav div {
			                 color: #f2f2f2;
			                 text-align: center;
			                 
			                 padding: 14px 16px;
			                 text-decoration: none;
			                 font-size: 30px;
		               }
		   #myTopnav{
		               
		               line-height: 80px;
		               }
		   .item{
		   	float:right;
		   	padding-left: 30px;
		   	padding-right: 40px;
		   /*font-size: 20px;*/}
		   .item1{
		   	float:right;
		   	background-color: #dd5347;
		   	padding-left: 40px;
		   	padding-right: 50px;
		   /*font-size: 20px;*/}
		   .item2{
		   	float:left;
		   	background-color: #dd5347;
		   	padding-left: 50px;
		   	padding-right: 50px;
		   	padding-bottom: 20px;
		   	padding-top: 20px;
		   /*font-size: 20px;*/}
		   
		   	.myhead {
    			color: #f2f2f2;
    			padding: 0 9%;
    			position: absolute;
    			top: 18%;
    			transition: color 1s;
    			width: 50%;
    			

			}

			
			h1 {
			font-family: "Lucida Console", Monaco, monospace;
    		font-size: 50px;
			}
		   .top {
	                 color: black;
	                 text-align: center;
	                 padding: 14px 16px;
	                 text-decoration: none;
	                 font-size: 20px;
	                 margin:50px;*/

	               
	             }
				form, .content {
				  width: 60%;
				  height: auto;
				  margin: 0px auto;
				  padding: 20px;
				  border: 0px solid #B0C4DE;
				  background: #F4F4F4;
				  border-radius: 0px 0px 10px 10px;
				  /*opacity: 0.7;*/

				}
				.input-group {
				  margin: 10px 0px 10px 0px;
				}
				.input-group label {
				  display: block;
				  text-align: left;
				  margin: 3px;
				}
				.input-group input {
				  height: 30px;
				  width: 93%;
				  padding: 5px 10px;
				  font-size: 16px;
				  border-radius: 5px;
				  border: 1px solid gray;
				}

				.input-group td {
				  height: 30px;
				  width: 93%;
				  padding: 5px 10px;
				  font-size: 20px;
				  border-radius: 5px;
				  border: 1px solid gray;
				}
				.header {
				  width: 60%;
				  margin: 50px auto 0px;
				  color: white;
				  background: #dd5347;
				  text-align: center;
				  border: 0px solid #B0C4DE;
				  border-bottom: none;
				  border-radius: 10px 10px 0px 0px;
				  padding: 20px;
				}
	</style>
	</head>
	<body class="body" id="body" background="">
	  <div class="topnav" id="myTopnav">
		<a  href="index.php" class="glyphicon glyphicon-home"  style="padding-left: 30px; padding-top: 15px ;color:white;font-size:30px"></a>
               <a   href="signup.php" style="color:white" class="gallery"><p class="item1" style="font-size:17px; ">CREATE ACCOUNT </p></a>
				
               <a   href="signin.php" style="color:white"><p class="item" style="font-size:17px;">SIGN IN</p></a>
                
        
	  </div>
	  <div class="header">
  		<h2>SIGN IN ACCOUNT</h2>
  	</div>

		<form action="display.php" method="POST" id="demo">
			<div class="top" >
				<div class="row">
					<div class="col-md-4 col-sm-3 padding-0 input-group">UserName:</div>
					<div class="col-md-8 col-sm-9 padding-0 input-group" >
						<input type="text" name="username" value="" id="username">
					</div>
		        </div>
                <div class="row">
			        <div class="col-md-4 col-sm-3 padding-0 input-group">password:</div>
			        <div class="col-md-8 col-sm-9 padding-0. input-group" >
				        <input type="password" name="password" value="" >
				    </div>
		        </div>
                <div class="row">
				<div class="col-md-4 col-sm-3 padding-0 input-group"><a href="signup.php">create account</a></div>
				<div class="col-md-2 col-sm-9 padding-0 input-group" >
				<input name="submit" type="submit" value="login">
			</div>
		</div>
	        </div>
		</form>	
<?php
		       if(isset($_POST['submit']))
		       {    //echo ("hello");
		           	$username=$_POST['username'];

		       		$password=$_POST['password'];

		       		//echo $password;

		       		if($username!=""&&$password!="")
		       		{	
		       			$sql = "SELECT * FROM user WHERE name='$username'
		       					UNION
		       					SELECT * FROM user WHERE password='$password'";
		       					//echo $sql;
                        $result = mysqli_query($con,$sql);

                        $count=mysqli_num_rows($result);

                        if($count>0)
                        {
                        	//echo ("hello");
                        	 header('location: display.php');
                        	 exit();
                        }
                        else
                        {
                        	echo"there is no user with that username or password";
                        }
                      

		       		}
		       		else
		       		{
		       			echo "there must be an empty data field";
		       		}
		       }
		       ?>
</body>
</html>

