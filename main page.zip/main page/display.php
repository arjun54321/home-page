<?php
include('connection.php');
error_reporting(1);
$query="SELECT * FROM USER";
$data=mysqli_query($con,$query);
$total=mysqli_num_rows($data);
if($total!=0)
{
	?>
	<!doctype html>
	<html>
	<head>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
	<style>
			div {
				    border-radius: 10px;
				    background-color: #eaecef;
				    padding: 10px;
				}
	    .topnav {
	                 color: #66d2e2;
	                 text-align: center;
	                 padding: 14px 16px;
	                 text-decoration: none;
	                 font-size: 15px;
	                 margin:50px;
	             }
	   /*.padding-0{
                     padding-right:0;
                     padding-left:0;
                 }*/

    </style>
	</head>
	<body>
		<div class="topnav">
		<div class="row table-responsive">
	<table class="table"> 
	
		<tr>
			<th>name</th>
			<th>country</div>
			<th>course</div>
			<th>id</div>
		</tr><br>
		<?php
		while($result=mysqli_fetch_assoc($data))
		{
			echo"<tr>
					<td>".$result['name']."</td>
					<td>".$result['checkbox']."</td>
					<td>".$result['dropdown']."</td>
					<td>".$result['id']."</td>
		  		  </tr>"."<br>";
		}
}
else
{
	echo "<br>"."table is empty";
}
?>
</table>
</div>
<div class="row">
				<div class="col-md-offset-5"><a href="signin.php">home</a></div>
			</div>
			
</div>

</body>
</html>
